import Header from "../Components/Header";
import Frame4 from "./Frame4";

const frame4Data = {
  text11: "현생에서 나눌 수 없었던",
  text10: (
    <>
      게임 속 이야기,
      <br />
      크로플에서 시작하세요
    </>
  ),
  sns: "인스타그램 같은 SNS에 올리기 눈치보였던 게임 속 소소한 이야기, 이제 크로플에서 기록하며 추억을 쌓아 보세요.",
  mockup1:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/mockup1@1x.png",
  text12: "오픈 알림 신청하기",
  spanText: "게임",
  spanText2: " 속 부캐들을 위한 ",
  spanText3: "SNS",
  text9: (
    <>
      내 피드를 공유하고
      <br />
      다양한 유저들의 게시물을 확인하세요
    </>
  ),
  mockup3:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/mockup3@1x.png",
  text8:
    "피드를 둘러보며 보며 자연스럽게 나와 취향이 비슷한 유저들과 만나 함께 이야기 나눌 수 있어요.",
  mockup2:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/mockup2@1x.png",
  animal_Crossing_New_Horizons__Chara:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/animal-crossing-new-horizons---character-artwork-02-2@2x.png",
  minecraft:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/minecraft@1x.png",
  snsCrofful: "게임 속 부캐들의 SNS, Crofful",
  text3: "오픈 소식을 가장 먼저 받아보세요!",
  inputType: "email",
  inputPlaceholder: "이메일을 입력해주세요.",
  text2: "개인정보 처리 방침에 동의합니다.",
  text1: "오픈 알림 신청하기",
  spanText4: (
    <>
      Crofful@gmail.com
      <br />
    </>
  ),
  spanText5: "Copyright ⓒ 2021 Crofful. All Right Reserved.",
  mockup4:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/mockup4@1x.png",
  animal_Crossing_New_Horizons__Chara2:
    "https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/animal-crossing-new-horizons---character-artwork-08-1@1x.png",
  text5: (
    <>
      이번에 크리스마스 섬 꾸미신거 진짜 예뻐요!!!👍👍
      <br />
      마이디자인도 올려주시는 것마다 취향저격 당하고 있습니당 💕
      <br />
      완전 팬이에요ㅎㅎ
    </>
  ),
  text4: (
    <>
      항상 응원해주셔서 감사해요❣😊
      <br />제 디자인을 좋아해주셔서 기분이 좋네요ㅎㅎ
    </>
  ),
  text6:
    "내가 만든 창작물을 팔로워들과 공유해요. 다운 받은 창작물을 적용하고 리뷰와 감사인사를 남겨요. 내가 좋아하는 크리에이터와 소통하고 응원할 수 있어요.",
  text7: (
    <>
      내가 만든 창작물을 공유하고
      <br />
      크리에이터와 소통해요
    </>
  ),
};

function Home() {
  return (
    <>
      <Header />
      <Frame4 {...frame4Data} />
    </>
  );
}

export default Home;
