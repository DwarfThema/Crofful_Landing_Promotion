import React from "react";
import styled from "styled-components";
import "../Routes/Frame4.css";

const OverlapGroup13 = styled.div`
  width: 1176px;
  height: 4501px;
  z-index: 3;
  position: relative;
  margin-top: -200px;
`;

const Page2 = styled.div`
  position: absolute;
  width: 1176px;
  top: 2581px;
  left: 0;
  display: flex;
  flex-direction: column;
  padding: 20px 68px;
  align-items: flex-start;
  min-height: 1920px;
`;

const Text11 = styled.div`
  min-height: 52px;
  margin-top: 60px;
  margin-left: 22px;
  font-family: var(--font-family-noto_sans);
  font-weight: 400;
  color: var(--eerie-black);
  font-size: 38px;
  letter-spacing: 0;
`;

const Text10 = styled.div`
  ${NotosansSemiBoldEerieBlack64px}
  width: 992px;
  min-height: 174px;
  align-self: center;
  margin-top: 7px;
  margin-right: 4px;
  letter-spacing: 0;
`;

const SNS = styled.div`
  ${NotosansNormalSonicSilver48px}
  width: 988px;
  min-height: 200px;
  align-self: center;
  margin-top: 40px;
  margin-right: 8px;
  letter-spacing: -2.4px;
  line-height: 70px;
`;

const OverlapGroupContainer = styled.div`
  width: 997px;
  height: 1320px;
  position: relative;
  margin-top: 27px;
`;

const OverlapGroup = styled.div`
  position: absolute;
  width: 578px;
  height: 1148px;
  top: 0;
  left: 419px;
`;

const Shadow = styled.div`
  position: absolute;
  width: 558px;
  height: 1137px;
  top: 11px;
  left: 20px;
  background-color: var(--tolopea);
  border-radius: 77px;
  filter: blur(20px);
  opacity: 0.2;
`;

const Mockup1 = styled.img`
  position: absolute;
  width: 572px;
  height: 1138px;
  top: 0;
  left: 0;
  object-fit: cover;
`;

const OverlapGroup2 = styled.div`
  position: absolute;
  width: 614px;
  height: 538px;
  top: 782px;
  left: 0;
`;

const OverlapGroup1 = styled.div`
  position: absolute;
  width: 614px;
  height: 538px;
  top: 0;
  left: 0;
`;

const Shadow1 = styled.img`
  position: absolute;
  width: 299px;
  height: 107px;
  top: 411px;
  left: 184px;
  mix-blend-mode: multiply;
`;

const Shadow11 = styled.img`
  position: absolute;
  width: 140px;
  height: 68px;
  top: 470px;
  left: 474px;
  mix-blend-mode: multiply;
`;

const Character = styled.img`
  position: absolute;
  width: 475px;
  height: 488px;
  top: 0;
  left: 0;
`;

const Butterfly = styled.img`
  position: absolute;
  width: 120px;
  height: 110px;
  top: 224px;
  left: 484px;
`;

const BG1 = styled.img`
  position: absolute;
  width: 1170px;
  height: 2734px;
  top: 0;
  left: 0;
`;

const View = styled.div`
  position: absolute;
  height: 172px;
  top: 1465px;
  left: 285px;
  display: flex;
  align-items: flex-start;
  min-width: 602px;
  transition: all 0.2s ease-in-out;
  cursor: pointer;

  &:hover {
    transform: scale(1.1);
  }
`;

const OverlapGroup9 = styled.div`
  width: 600px;
  height: 172px;
  position: relative;
`;

const Shadow2 = styled.div`
  position: absolute;
  width: 500px;
  height: 155px;
  top: 17px;
  left: 50px;
  background-color: #663afe;
  border-radius: 90px;
  filter: blur(50px);
  opacity: 0.3;
`;

const Button = styled.div`
  position: absolute;
  width: 600px;
  height: 155px;
  top: 0;
  left: 0;
  background-color: #854cff;
  border-radius: 90px;
`;

const Text12 = styled.div`
  position: absolute;
  width: 470px;
  top: 51px;
  left: 65px;
  font-family: var(--font-family-roboto);
  font-weight: 700;
  color: var(--white);
  font-size: var(--font-size-m);
  text-align: center;
  letter-spacing: 0;
`;

const Crofful = styled.img`
  position: absolute;
  width: 899px;
  height: 232px;
  top: 911px;
  left: 129px;
`;

const SNS1 = styled.div`
  ${NanumsquareotfExtraExtraBoldWhite52}
  position: absolute;
  width: 998px;
  top: 1198px;
  left: 86px;
  text-shadow: 0px 4px 8px #663afe4c;
  text-align: center;
  letter-spacing: 2.6px;
`;

const Span0 = styled.span`
  ${NanumsquareotfExtraExtraBoldWhite52}
  letter-spacing: 1.35px;
`;

const Span1 = styled.span`
  font-family: var(--font-family-nanumsquareotf-regular);
  font-weight: 400;
  color: var(--white);
  font-size: var(--font-size-l);
  letter-spacing: 1.35px;
`;

const Rectangle35 = styled.div`
  position: absolute;
  width: 650px;
  height: 3px;
  top: 1271px;
  left: 260px;
  background-color: #ffffff66;
  box-shadow: 0px 4px 8px #653afd33;
`;

const OverlapGroup14 = styled.div`
  width: 1170px;
  z-index: 1;
  display: flex;
  flex-direction: column;
  padding: 25.9px 24.1px;
  align-items: flex-end;
  min-height: 2437px;
  background-color: #f9f2ff;
`;

const Text9 = styled.div`
  ${NotosansSemiBoldEerieBlack64px}
  min-height: 174px;
  align-self: center;
  margin-top: 100px;
  margin-left: 2px;
  min-width: 992px;
  letter-spacing: 0;
`;

const OverlapGroupContainer1 = styled.div`
  width: 1094px;
  height: 2071px;
  position: relative;
  margin-top: 40px;
`;

const OverlapGroup15 = styled.div`
  position: absolute;
  width: 1028px;
  height: 1281px;
  top: 0;
  left: 38px;
`;

const OverlapGroup6 = styled.div`
  position: absolute;
  width: 521px;
  height: 1039px;
  top: 243px;
  left: 507px;
`;

const Shadow3 = styled.div`
  position: absolute;
  width: 505px;
  height: 1029px;
  top: 10px;
  left: 17px;
  background-color: var(--tolopea);
  border-radius: 77px;
  filter: blur(20px);
  opacity: 0.2;
`;

const Mockup3 = styled.img`
  position: absolute;
  width: 520px;
  height: 1030px;
  top: 0;
  left: 0;
  object-fit: cover;
`;

const Text8 = styled.div`
  ${NotosansNormalSonicSilver48px}
  position: absolute;
  width: 990px;
  top: 0;
  left: 0;
  letter-spacing: -2.4px;
  line-height: 70px;
`;

const OverlapGroup11 = styled.div`
  position: absolute;
  width: 495px;
  height: 554px;
  top: 176px;
  left: 73px;
`;

const Shadow12 = styled.img`
  position: absolute;
  width: 275px;
  height: 109px;
  top: 445px;
  left: 0;
  mix-blend-mode: multiply;
`;

const Shadow13 = styled.img`
  position: absolute;
  width: 131px;
  height: 216px;
  top: 147px;
  left: 364px;
  mix-blend-mode: multiply;
`;

const Shadow14 = styled.img`
  position: absolute;
  width: 242px;
  height: 110px;
  top: 386px;
  left: 219px;
  mix-blend-mode: multiply;
`;

const MaskGroup = styled.img`
  position: absolute;
  width: 235px;
  height: 453px;
  top: 0;
  left: 223px;
`;

const MaskGroup1 = styled.img`
  position: absolute;
  width: 255px;
  height: 489px;
  top: 24px;
  left: 13px;
`;

const OverlapGroupContainer2 = styled.div`
  position: absolute;
  width: 1094px;
  height: 1219px;
  top: 852px;
  left: 0;
`;

const OverlapGroup7 = styled.div`
  position: absolute;
  width: 527px;
  height: 1040px;
  top: 0;
  left: 0;
`;

const Shadow4 = styled.div`
  position: absolute;
  width: 505px;
  height: 1030px;
  top: 10px;
  left: 22px;
  background-color: var(--tolopea);
  border-radius: 77px;
  filter: blur(20px);
  opacity: 0.2;
`;

const Mockup2 = styled.img`
  position: absolute;
  width: 520px;
  height: 1032px;
  top: 0;
  left: 0;
  object-fit: cover;
`;

const OverlapGroup10 = styled.div`
  position: absolute;
  width: 712px;
  height: 580px;
  top: 639px;
  left: 381px;
`;

const Shadow15 = styled.img`
  position: absolute;
  width: 217px;
  height: 245px;
  top: 43px;
  left: 75px;
  mix-blend-mode: multiply;
`;

const Shadow21 = styled.img`
  position: absolute;
  width: 503px;
  height: 146px;
  top: 400px;
  left: 209px;
  mix-blend-mode: multiply;
`;

const Shadow16 = styled.img`
  position: absolute;
  width: 268px;
  height: 97px;
  top: 386px;
  left: 72px;
  mix-blend-mode: multiply;
`;

const AnimalCrossingNewHorizonsCharacterA = styled.img`
  position: absolute;
  width: 470px;
  height: 472px;
  top: 0;
  left: 0;
  object-fit: cover;
`;

const Minecraft = styled.img`
  position: absolute;
  width: 399px;
  height: 562px;
  top: 18px;
  left: 254px;
  object-fit: cover;
`;

const OverlapGroup18 = styled.div`
  width: 1174px;
  height: 4434px;
  z-index: 2;
  position: relative;
`;

const SubmitPage = styled.div`
  position: absolute;
  width: 1170px;
  top: 1900px;
  left: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 2534px;
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/bg5@1x.svg);
  background-size: 100% 100%;
`;

const OverlapGroup3 = styled.div`
  width: 1100px;
  margin-top: 578px;
  display: flex;
  flex-direction: column;
  padding: 105px 0;
  align-items: center;
  min-height: 839px;
  background-color: #ffffffcc;
  border-radius: 70px;
  box-shadow: 0px 30px 30px #653afd4c;
`;

const SNSCrofful = styled.div`
  ${NotosansNormalSonicSilver48px}
  width: 890px;
  min-height: 70px;
  text-align: center;
  letter-spacing: -2.4px;
  line-height: 70px;
  white-space: nowrap;
`;

const Text3 = styled.h1`
  width: 980px;
  margin-bottom: -4px;
  min-height: 80px;
  margin-top: 19px;
  font-family: var(--font-family-noto_sans);
  font-weight: 800;
  color: var(--eerie-black);
  font-size: var(--font-size-xxl);
  text-align: center;
  letter-spacing: 0;
  line-height: 84px;
  white-space: nowrap;
`;

const OverlapGroup21 = styled.div`
  height: 120px;
  margin-top: 75px;
  display: flex;
  padding: 31px 37px;
  align-items: flex-end;
  min-width: 900px;
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/inputbox@1x.svg);
  background-size: 100% 100%;
`;

const Ti2aHd = styled.input`
  width: 826px;
  height: 54px;
  background-color: transparent;
  font-family: var(--font-family-noto_sans);
  font-weight: 400;
  color: var(--mountain-mist);
  font-size: var(--font-size-s);
  letter-spacing: 0;
  border: 0;
  padding: 0;

  &::placeholder {
    color: #99999999;
  }
`;

const View1 = styled.div`
  align-self: flex-start;
  margin-top: 30px;
  margin-left: 100px;
  display: flex;
  align-items: flex-start;
  min-width: 563px;
`;

const OverlapGroup12 = styled.div`
  width: 40px;
  height: 40px;
  position: relative;
  border-radius: 20px;
`;

const Default = styled.div`
  position: absolute;
  height: 40px;
  top: 0;
  left: 0;
  display: flex;
  padding: 8.1px 3px;
  align-items: flex-start;
  min-width: 40px;
  background-color: var(--white);
  border-radius: 20px;
  border: 3px solid var(--mountain-mist);
`;

const Check = styled.img`
  width: 28px;
  height: 19px;
`;

const Agree = styled.div`
  position: absolute;
  height: 40px;
  top: 0;
  left: 0;
  display: flex;
  padding: 9.9px 6px;
  align-items: flex-end;
  min-width: 40px;
  background-color: var(--electric-violet);
  border-radius: 90px;
`;

const Text2 = styled.div`
  width: 507px;
  min-height: 40px;
  margin-left: 14px;
  font-family: var(--font-family-noto_sans);
  font-weight: 400;
  color: var(--mountain-mist);
  font-size: var(--font-size-xs);
  letter-spacing: 0;
`;

const View2 = styled.div`
  margin-top: 60px;
  margin-left: 2px;
  display: flex;
  align-items: flex-start;
  min-width: 602px;
  transition: all 0.2s ease-in-out;
  cursor: pointer;

  &:hover {
    transform: scale(1.1);
  }
`;

const OverlapGroup4 = styled.div`
  height: 120px;
  display: flex;
  padding: 35px 105px;
  align-items: flex-start;
  min-width: 600px;
  background-color: var(--electric-violet);
  border-radius: 90px;
  box-shadow: 0px 15px 20px #653afd33;
`;

const Text1 = styled.div`
  width: 390px;
  min-height: 40px;
  font-family: var(--font-family-roboto);
  font-weight: 700;
  color: var(--white);
  font-size: var(--font-size-s);
  text-align: center;
  letter-spacing: 0;
`;

const OverlapGroup41 = styled.div`
  height: 817px;
  margin-top: 300px;
  display: flex;
  padding: 101px 117px;
  align-items: flex-start;
  min-width: 1170px;
  background-color: #492b86;
  box-shadow: 0px 15px 20px #653afd33;
`;

const CroffulgmailcomCo = styled.div`
  ${NotosansBoldBlueViolet32px}
  width: 935px;
  min-height: 100px;
  text-align: center;
  letter-spacing: 0;
  line-height: 50px;
`;

const Span11 = styled.span`
  font-family: var(--font-family-noto_sans);
  font-weight: 400;
  color: var(--blue-violet);
  font-size: var(--font-size-xs);
`;

const OverlapGroup5 = styled.div`
  position: absolute;
  width: 1170px;
  height: 1909px;
  top: 0;
  left: 0;
`;

const BG4 = styled.div`
  position: absolute;
  width: 1170px;
  height: 1900px;
  top: 0;
  left: 0;
  background-color: var(--white);
`;

const OverlapGroup8 = styled.div`
  position: absolute;
  width: 552px;
  height: 1092px;
  top: 667px;
  left: 129px;
`;

const Shadow5 = styled.div`
  position: absolute;
  width: 531px;
  height: 1082px;
  top: 10px;
  left: 21px;
  background-color: var(--tolopea);
  border-radius: 77px;
  filter: blur(20px);
  opacity: 0.2;
`;

const Mockup4 = styled.img`
  position: absolute;
  width: 543px;
  height: 1082px;
  top: 0;
  left: 0;
  object-fit: cover;
`;

const OverlapGroup16 = styled.div`
  position: absolute;
  width: 555px;
  height: 576px;
  top: 1333px;
  left: 562px;
`;

const Shadow17 = styled.img`
  position: absolute;
  width: 382px;
  height: 137px;
  top: 439px;
  left: 150px;
  mix-blend-mode: multiply;
`;

const AnimalCrossingNewHorizonsCharacterA1 = styled.img`
  position: absolute;
  width: 555px;
  height: 555px;
  top: 0;
  left: 0;
  object-fit: cover;
`;

const Chat = styled.div`
  position: absolute;
  width: 689px;
  top: 1018px;
  left: 416px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  min-height: 315px;
`;

const OverlapGroup22 = styled.div`
  height: 179px;
  align-self: flex-end;
  margin-right: -16px;
  display: flex;
  padding: 31px 48px;
  align-items: flex-start;
  min-width: 650px;
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/vector-1@1x.svg);
  background-size: 100% 100%;
`;

const Text5 = styled.div`
  width: 524px;
  min-height: 90px;
  font-family: var(--font-family-nanumsquareotf-bold);
  font-weight: 700;
  color: var(--sonic-silver);
  font-size: var(--font-size-xxs);
  letter-spacing: -1.1px;
  line-height: 30px;
`;

const OverlapGroup31 = styled.div`
  height: 155px;
  margin-top: 16px;
  margin-left: -10px;
  display: flex;
  padding: 29.6px 60.1px;
  justify-content: flex-end;
  align-items: flex-start;
  min-width: 510px;
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/vector@2x.svg);
  background-size: 100% 100%;
`;

const Text4 = styled.div`
  min-height: 60px;
  font-family: var(--font-family-nanumsquareotf-bold);
  font-weight: 700;
  color: var(--white);
  font-size: var(--font-size-xxs);
  letter-spacing: -1.1px;
  line-height: 30px;
`;

const Text6 = styled.div`
  ${NotosansNormalSonicSilver48px}
  position: absolute;
  width: 990px;
  top: 353px;
  left: 90px;
  letter-spacing: -2.4px;
  line-height: 70px;
`;

const Text7 = styled.div`
  ${NotosansSemiBoldEerieBlack64px}
  position: absolute;
  width: 992px;
  top: 139px;
  left: 90px;
  letter-spacing: 0;
`;

function Zt2H0a() {
  return (
    <FixedBar>
      <OverlapGroup12>
        <Crofful src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/crofful-1@2x.svg" />
      </OverlapGroup12>
    </FixedBar>
  );
}

const FixedBar = styled.div`
  position: fixed;
  height: 130px;
  top: 0;
  left: 0;
  z-index: 4;
  display: flex;
  align-items: flex-start;
  min-width: 1170px;
  background-color: #ffffff4c;
  backdrop-filter: blur(25px) brightness(100%);
  -webkit-backdrop-filter: blur(25px) brightness(100%);
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/grad@1x.svg);
  background-size: 100% 100%;
`;

const OverlapGroup12 = styled.div`
  height: 134px;
  margin-top: -2px;
  display: flex;
  padding: 31.9px 38px;
  align-items: flex-start;
  min-width: 1170px;
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/line@1x.svg);
  background-size: 100% 100%;
`;

const Crofful = styled.img`
  width: 312px;
  height: 70px;
`;

export const NotosansNormalSonicSilver48px = css`
  color: var(--sonic-silver);
  font-family: var(--font-family-noto_sans);
  font-size: var(--font-size-m);
  font-weight: 400;
  font-style: normal;
`;

export const NotosansSemiBoldEerieBlack64px = css`
  color: var(--eerie-black);
  font-family: var(--font-family-noto_sans);
  font-size: var(--font-size-xl);
  font-weight: 600;
  font-style: normal;
`;

export const NanumsquareotfExtraExtraBoldWhite52 = css`
  color: var(--white);
  font-family: var(--font-family-nanumsquareotf-extrabold);
  font-size: var(--font-size-l);
  font-weight: 800;
  font-style: normal;
`;

export const NotosansBoldBlueViolet32px = css`
  color: var(--blue-violet);
  font-family: var(--font-family-noto_sans);
  font-size: var(--font-size-xs);
  font-weight: 700;
  font-style: normal;
`;

function Frame4(props) {
  const {
    text11,
    text10,
    sns,
    mockup1,
    text12,
    spanText,
    spanText2,
    spanText3,
    text9,
    mockup3,
    text8,
    mockup2,
    animal_Crossing_New_Horizons__Chara,
    minecraft,
    snsCrofful,
    text3,
    inputType,
    inputPlaceholder,
    text2,
    text1,
    spanText4,
    spanText5,
    mockup4,
    animal_Crossing_New_Horizons__Chara2,
    text5,
    text4,
    text6,
    text7,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-4 screen">
        <OverlapGroup13>
          <Page2>
            <Text11>{text11}</Text11>
            <Text10>{text10}</Text10>
            <SNS>{sns}</SNS>
            <OverlapGroupContainer>
              <OverlapGroup>
                <Shadow></Shadow>
                <Mockup1 src={mockup1} />
              </OverlapGroup>
              <OverlapGroup2>
                <OverlapGroup1>
                  <Shadow1 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-1@2x.svg" />
                  <Shadow11 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-2@2x.svg" />
                  <Character src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/character@2x.svg" />
                </OverlapGroup1>
                <Butterfly src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/butterfly@2x.svg" />
              </OverlapGroup2>
            </OverlapGroupContainer>
          </Page2>
          <BG1 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/bg1@1x.svg" />
          <View>
            <OverlapGroup9>
              <Shadow2></Shadow2>
              <Button></Button>
              <Text12>{text12}</Text12>
            </OverlapGroup9>
          </View>
          <Crofful src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/crofful@1x.svg" />
          <SNS1>
            <Span0>{spanText}</Span0>
            <Span1>{spanText2}</Span1>
            <Span0>{spanText3}</Span0>
          </SNS1>
          <Rectangle35></Rectangle35>
        </OverlapGroup13>
        <Zt2H0a />
        <OverlapGroup14>
          <Text9>{text9}</Text9>
          <OverlapGroupContainer1>
            <OverlapGroup15>
              <OverlapGroup6>
                <Shadow3></Shadow3>
                <Mockup3 src={mockup3} />
              </OverlapGroup6>
              <Text8>{text8}</Text8>
              <OverlapGroup11>
                <Shadow12 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-5@2x.svg" />
                <Shadow13 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-6@2x.svg" />
                <Shadow14 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-7@2x.svg" />
                <MaskGroup src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/mask-group@2x.svg" />
                <MaskGroup1 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/mask-group-1@2x.svg" />
              </OverlapGroup11>
            </OverlapGroup15>
            <OverlapGroupContainer2>
              <OverlapGroup7>
                <Shadow4></Shadow4>
                <Mockup2 src={mockup2} />
              </OverlapGroup7>
              <OverlapGroup10>
                <Shadow15 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-3@2x.svg" />
                <Shadow21 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow2@2x.svg" />
                <Shadow16 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1-4@2x.svg" />
                <AnimalCrossingNewHorizonsCharacterA
                  src={animal_Crossing_New_Horizons__Chara}
                />
                <Minecraft src={minecraft} />
              </OverlapGroup10>
            </OverlapGroupContainer2>
          </OverlapGroupContainer1>
        </OverlapGroup14>
        <OverlapGroup18>
          <SubmitPage>
            <OverlapGroup3>
              <SNSCrofful>{snsCrofful}</SNSCrofful>
              <Text3>{text3}</Text3>
              <OverlapGroup21>
                <Ti2aHd placeholder={inputPlaceholder} type={inputType} />
              </OverlapGroup21>
              <View1>
                <OverlapGroup12>
                  <Default>
                    <Check src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/check@2x.svg" />
                  </Default>
                  <Agree>
                    <Check src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/chack@2x.svg" />
                  </Agree>
                </OverlapGroup12>
                <Text2>{text2}</Text2>
              </View1>
              <View2>
                <OverlapGroup4>
                  <Text1>{text1}</Text1>
                </OverlapGroup4>
              </View2>
            </OverlapGroup3>
            <OverlapGroup41>
              <CroffulgmailcomCo>
                <span className="notosans-bold-blue-violet-32px">
                  {spanText4}
                </span>
                <Span11>{spanText5}</Span11>
              </CroffulgmailcomCo>
            </OverlapGroup41>
          </SubmitPage>
          <OverlapGroup5>
            <BG4></BG4>
            <OverlapGroup8>
              <Shadow5></Shadow5>
              <Mockup4 src={mockup4} />
            </OverlapGroup8>
            <OverlapGroup16>
              <Shadow17 src="https://anima-uploads.s3.amazonaws.com/projects/61c2ef23efab2ce788722f85/releases/61c2ef43e9955cc59ea4edab/img/shadow1@2x.svg" />
              <AnimalCrossingNewHorizonsCharacterA1
                src={animal_Crossing_New_Horizons__Chara2}
              />
            </OverlapGroup16>
            <Chat>
              <OverlapGroup22>
                <Text5>{text5}</Text5>
              </OverlapGroup22>
              <OverlapGroup31>
                <Text4>{text4}</Text4>
              </OverlapGroup31>
            </Chat>
            <Text6>{text6}</Text6>
            <Text7>{text7}</Text7>
          </OverlapGroup5>
        </OverlapGroup18>
      </div>
    </div>
  );
}

export default Frame4;
